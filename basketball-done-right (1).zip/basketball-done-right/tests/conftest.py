import os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for p in (ROOT, os.path.join(ROOT, "stintbuild"), os.path.join(ROOT, "pomodel"), os.path.join(ROOT, "pbplib")):
    if p not in sys.path: sys.path.insert(0, p)
